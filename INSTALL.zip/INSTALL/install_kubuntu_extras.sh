#!/bin/bash

# Exit immediately if a command fails
set -e

# Log file
LOGFILE="install_log.txt"

# Function to log messages
log() {
    echo "$1" | tee -a "$LOGFILE"
}

# Check if the script is run as root
if [[ $EUID -ne 0 ]]; then
    log "This script must be run as root. Please use 'sudo'."
    exit 1
fi

# Start of the script
log "========================"
log "Kubuntu Extras Installer"
log "========================"

# Prompt for confirmation
read -p "Do you want to proceed with the installation? (y/n): " choice
if [[ "$choice" != "y" ]]; then
    log "Installation aborted by the user."
    exit 0
fi

# Update package lists
log "Updating package lists..."
sudo apt update | tee -a "$LOGFILE"

# Upgrade the system
log "Upgrading system packages..."
sudo apt upgrade -y | tee -a "$LOGFILE"

# Install Kubuntu restricted extras
log "Installing Kubuntu restricted extras..."
sudo apt install -y kubuntu-restricted-extras | tee -a "$LOGFILE"

# Install additional software (programs with spaces vlc gimp htop etc.)
log "Installing VLC, GIMP, and other utilities..."

# Install packages
echo "Installing essential programs..."
sudo apt install -y \
vlc \
gimp \
htop \
inkscape \
firefox \
curl \
git \
ufw \
kget \
strawberry \
gnome-disk-utility \
trimage \
xdm \
stacer \
chromium \
transmission-cli \
clamav \
wget \
| tee -a "$LOGFILE"

# Clean up
log "Cleaning up unnecessary packages..."
sudo apt autoremove -y | tee -a "$LOGFILE"
sudo apt autoclean | tee -a "$LOGFILE"


# Define the SCREEN, desktop, and the color (in #RRGGBB format)
#!/bin/bash

# Define the desired color
#!/bin/bash

# Define the desired color
# COLOR="#FF5733"
#
# # Get the current user's home directory
# USER_HOME=$(eval echo ~${SUDO_USER:-$USER})
#
# # Path to the Plasma configuration file
# CONFIG_FILE="$USER_HOME/.config/plasma-org.kde.plasma.desktop-appletsrc"
#
# # Check if the configuration file exists
# if [ ! -f "$CONFIG_FILE" ]; then
#     echo "Error: Configuration file not found at $CONFIG_FILE"
#     exit 1
# fi
#
# # Update the configuration file to set the solid color
# sed -i "/\[Wallpaper\]/,/plugin=/s/plugin=.*/plugin=org.kde.color/" "$CONFIG_FILE"
# sed -i "/\[Wallpaper\]/,/Color=/s/Color=.*/Color=$COLOR/" "$CONFIG_FILE"
#
# # Restart Plasma shell to apply changes
# echo "Restarting Plasma..."
# killall plasmashell
# sleep 1  # Wait a bit for plasmashell to quit
# plasmashell --replace &
#


# FIREWALL

# Allow HTTP (Port 80)
sudo ufw allow 80/tcp

# Allow HTTPS (Port 443)
sudo ufw allow 443/tcp

# Enable the firewall
sudo ufw enable

# Set default policies to deny all incoming traffic except the allowed ones
sudo ufw default deny incoming
sudo ufw default allow outgoing

# Check the firewall status
sudo ufw status

# List of domains to block
BLOCKED_DOMAINS=(
    "olifeja.lt"
    "loto.lt"
    "fb.com"
    "0rbit.com"
    "adclicksrv.com"
    "ads.yieldmanager.com"
    "adservinginternational.com"
    "affiliate-network.com"
    "amazonaws.com"  # Often used for hosting phishing pages
    "badb.com"
    "clicksor.com"
    "clickserve.cc"
    "datr.com"  # Facebook's tracker, but can be used by malicious parties
    "doubleclick.net"  # Google's ad network often misused in malicious ads
    "g.doubleclick.net"
    "malwaredomainlist.com"
    "phishing.com"
    "static.advertising.com"
    "track.360yield.com"
    "track.adnxs.com"
    "tracking.server.com"
    "unwanted-ads.net"
    "unsafeweb.com"
    "winfixer.com"  # Known for redirecting to fake antivirus sites
    "yourdirtywork.com"
    "zeusbot.com"  # Common in botnet infections
    "amarketplace.com"  # Scam and fraudulent sites
    "contentdelivery.com"  # Often used in fake update prompts
    "infoproc.net"  # Used in click fraud schemes
    "clickture.com"
    "spamhub.com"  # Used to host spam websites
    "clickrewards.com"  # Part of click fraud campaigns
    "trackedlink.com"
    "adservice.com"
    "trackmyads.com"  # Known for tracking and delivering unwanted ads
    "spybot.com"  # Often a rogue program related to adware
    "cool-search.com"  # Redirects to malicious or fake websites
    "fakewebsecurity.com"
    "adsrvmedia.com"  # Known to deliver adware
    "smartlink.com"  # Associated with fraudulent redirection
    "trustedsurveys.com"  # Often used in phishing schemes
    "phishing-attack.com"
    "ads2go.com"
    "securitycheckup.com"  # Fake security warning sites
    "shadyclicks.com"
    "malwareexpert.com"
    "botattack.com"  # Associated with botnet attacks
    "zeusbot.net"  # Related to the Zeus botnet, often used in financial malware
    "scamtracker.com"  # Used to host scams
    "browser-optimizer.com"  # A malicious site posing as optimization software
    "tools-virus.com"  # Known to distribute virus warnings
    "spamlord.com"  # Hosts spam or fraudulent content
    "admiraltracker.com"  # Tracker used for malicious purposes
    "data-collection.com"  # Data harvesting and fraudulent activities
    "research-adnetwork.com"  # Unwanted ad network and trackers
    "rootkit.com"  # Used for malware-related rootkits
    "badads.com"  # Known for ad fraud and malware distribution
    "fraudulentads.com"  # Used in scam advertising
    "advertising-scams.com"
    "clickfraudtracker.com"  # Associated with click fraud campaigns
    "ssl-malware.com"  # Malicious SSL-related site
    "fake-dns.com"  # DNS manipulation and fraud
    "cyberthreat.com"  # Associated with cybersecurity threats
    "malwarehost.com"  # Malware hosting site
    "unsafe-surf.com"  # Risky site hosting malicious content
    "phishing-host.com"  # Common in phishing attacks
    "trojan-distribution.com"  # Used for distributing trojans
    "security-error.com"  # A site often used in fake warnings
    "scamlandingpage.com"  # Scam landing page frequently used in phishing
    "unsafe-exe.com"  # Hosts dangerous .exe files
    "clickblocker.com"  # Used for malicious redirecting
    "attack-router.com"  # Associated with network-based attacks
    "clickdisguise.com"  # Fraudulent click and ad campaigns
    "fraudulent-redirect.com"  # Redirects to harmful or scam websites
)

# Backup the original hosts file (ensure sudo permission)
echo "Backing up /etc/hosts..."
sudo cp /etc/hosts /etc/hosts.bak

# Loop through each domain and add it to /etc/hosts if not already there
for DOMAIN in "${BLOCKED_DOMAINS[@]}"; do
    # Check if the domain is already in /etc/hosts
    if ! sudo grep -q "$DOMAIN" /etc/hosts; then
        echo "Adding domain $DOMAIN to /etc/hosts"
        echo "127.0.0.1 $DOMAIN" | sudo tee -a /etc/hosts > /dev/null
    else
        echo "Domain $DOMAIN is already in /etc/hosts"
    fi
done

# Flush DNS cache if necessary (command depends on your Linux distribution)
echo "Flushing DNS cache..."
if command -v systemctl > /dev/null; then
    sudo systemctl restart NetworkManager
elif command -v service > /dev/null; then
    sudo service network-manager restart
fi

echo "Blocking script completed."
#!/bin/bash


# Function to disable a service with error checking
disable_service() {
    local service_name="$1"
    echo "Checking if $service_name is active..."
    if systemctl list-units --full --all | grep -q "$service_name"; then
        echo "Disabling $service_name..."
        sudo systemctl stop "$service_name" || { echo "Failed to stop $service_name"; return 1; }
        sudo systemctl disable "$service_name" || { echo "Failed to disable $service_name"; return 1; }
        echo "$service_name has been disabled."
    else
        echo "$service_name is not found or not running."
    fi
}

# Function to modify systemd-journald.conf to use volatile storage (no persistent logs)
disable_persistent_logging() {
    local journald_conf="/etc/systemd/journald.conf"

    # Check if journald.conf exists
    if [ ! -f "$journald_conf" ]; then
        echo "$journald_conf not found!"
        return 1
    fi

    echo "Modifying $journald_conf to disable persistent logging..."

    # Backup the original journald.conf file if not already backed up
    if [ ! -f "${journald_conf}.bak" ]; then
        echo "Backing up original $journald_conf to ${journald_conf}.bak..."
        sudo cp "$journald_conf" "${journald_conf}.bak" || { echo "Failed to create backup!"; return 1; }
    fi

    # Modify the Storage option to 'volatile'
    sudo sed -i 's/^#*Storage=.*/Storage=volatile/' "$journald_conf" || { echo "Failed to update Storage option in $journald_conf"; return 1; }

    # Restart systemd-journald to apply the changes
    echo "Restarting systemd-journald to apply the changes..."
    sudo systemctl restart systemd-journald || { echo "Failed to restart systemd-journald!"; return 1; }

    echo "Persistent logging has been disabled. Logs will now be stored in memory only."
}

# Disable services
disable_service "rsyslog"
disable_service "systemd-journald"
disable_service "bluetooth"
disable_service "mysql"
disable_service "apache2"
disable_service "ssh"
disable_service "nginx"
disable_service "postfix"
disable_service "docker"
disable_service "cups"

# Disable persistent logging by modifying systemd-journald.conf
disable_persistent_logging

echo "All specified services have been processed, and persistent logging has been disabled."


wget -qO- https://packages.microsoft.com/keys/microsoft.asc | sudo gpg --dearmor > /usr/share/keyrings/microsoft-archive-keyring.gpg
echo "deb [arch=amd64 signed-by=/usr/share/keyrings/microsoft-archive-keyring.gpg] https://packages.microsoft.com/repos/vscode stable main" | sudo tee /etc/apt/sources.list.d/vscode.list > /dev/null

sudo apt update
sudo apt install code

echo "INSTALL WS CODE EXTENSIONS"
code --no-sandbox --user-data-dir="$HOME/.vscode-data" --install-extension <extension-id>


# Final message
log "========================"
log "Installation completed successfully!"
log "Log file saved to $LOGFILE"
log "========================"
